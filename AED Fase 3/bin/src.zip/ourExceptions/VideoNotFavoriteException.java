package ourExceptions;

public class VideoNotFavoriteException extends Exception {

	private static final long serialVersionUID = 0L;

	public VideoNotFavoriteException() {
		// TODO Auto-generated constructor stub
	}

	
}
