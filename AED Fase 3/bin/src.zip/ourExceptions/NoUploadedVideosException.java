package ourExceptions;

public class NoUploadedVideosException extends Exception {

	private static final long serialVersionUID = 0L;
	
	public NoUploadedVideosException() {
		// TODO Auto-generated constructor stub
	}

}
