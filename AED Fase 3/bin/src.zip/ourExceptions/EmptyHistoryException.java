package ourExceptions;

public class EmptyHistoryException extends Exception {

	private static final long serialVersionUID = 0L;
	
	public EmptyHistoryException() {
		// TODO Auto-generated constructor stub
	}


}
