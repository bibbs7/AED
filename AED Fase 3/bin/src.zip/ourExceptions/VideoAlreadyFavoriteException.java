package ourExceptions;

public class VideoAlreadyFavoriteException extends Exception {

	private static final long serialVersionUID = 0L;
	
	public VideoAlreadyFavoriteException() {
		// TODO Auto-generated constructor stub
	}

	
}
