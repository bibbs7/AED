package ourExceptions;

public class TagAlreadyExsitsException extends Exception {

	private static final long serialVersionUID = 0L;
	
	public TagAlreadyExsitsException() {
		// TODO Auto-generated constructor stub
	}

	
}
