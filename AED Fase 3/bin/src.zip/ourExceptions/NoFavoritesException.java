package ourExceptions;

public class NoFavoritesException extends Exception {

	private static final long serialVersionUID = 0L;
	
	public NoFavoritesException() {
		// TODO Auto-generated constructor stub
	}



}
