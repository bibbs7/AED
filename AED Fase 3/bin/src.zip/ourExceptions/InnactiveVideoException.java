package ourExceptions;

public class InnactiveVideoException extends Exception {

	private static final long serialVersionUID = 0L;
	
	public InnactiveVideoException() {
		// TODO Auto-generated constructor stub
	}

	

}
