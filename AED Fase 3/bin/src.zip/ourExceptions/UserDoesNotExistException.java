package ourExceptions;

public class UserDoesNotExistException extends Exception {

	private static final long serialVersionUID = 0L;
	
	public UserDoesNotExistException() {
		// TODO Auto-generated constructor stub
	}

}
