package ourExceptions;

public class TagDoesNotExistException extends Exception {

	private static final long serialVersionUID = 0L;
	
	public TagDoesNotExistException() {
		// TODO Auto-generated constructor stub
	}


}
