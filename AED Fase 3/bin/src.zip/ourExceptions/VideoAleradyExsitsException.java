package ourExceptions;

public class VideoAleradyExsitsException extends Exception {

	private static final long serialVersionUID = 0L;
	
	public VideoAleradyExsitsException() {
		// TODO Auto-generated constructor stub
	}

	
}
