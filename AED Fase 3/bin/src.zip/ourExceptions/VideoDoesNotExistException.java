package ourExceptions;

public class VideoDoesNotExistException extends Exception {

	private static final long serialVersionUID = 0L;
	
	public VideoDoesNotExistException() {
		// TODO Auto-generated constructor stub
	}

	
}
