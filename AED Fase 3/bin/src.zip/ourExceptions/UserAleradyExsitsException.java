package ourExceptions;

public class UserAleradyExsitsException extends Exception {

	private static final long serialVersionUID = 0L;
	
	public UserAleradyExsitsException() {
		super();
	}
}
