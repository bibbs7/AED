package ourExceptions;

public class InvalidDurationException extends Exception {

	private static final long serialVersionUID = 0L;
	
	public InvalidDurationException() {
		// TODO Auto-generated constructor stub
	}

}
