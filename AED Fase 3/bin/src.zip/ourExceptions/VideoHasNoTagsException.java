package ourExceptions;

public class VideoHasNoTagsException extends Exception {

	private static final long serialVersionUID = 0L;
	
	public VideoHasNoTagsException() {
		// TODO Auto-generated constructor stub
	}

	
}
