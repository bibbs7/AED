package dataStructures;

public interface IteratableStack<E> extends Stack<E> {


	public Iterator<E> list();


}
