package dataStructures;

public interface IteratableQueue<E> extends Queue<E> {

	public Iterator<E> list();

}
